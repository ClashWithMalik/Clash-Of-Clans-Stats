# Chocolate Clash Go API
Unofficial API of chocolateclash.com for farming clans looking to automate clan moderation and management based on tracked results on the website.
